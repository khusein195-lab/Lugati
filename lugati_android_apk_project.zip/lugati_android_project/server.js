const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const ROOT = __dirname;
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || 'gpt-6-astra';
const mime = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.webmanifest':'application/manifest+json','.css':'text/css; charset=utf-8'};
function send(res, status, data) { res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET,POST,OPTIONS','Access-Control-Allow-Headers':'Content-Type'}); res.end(JSON.stringify(data)); }
function readBody(req) { return new Promise((resolve,reject)=>{let data='';req.on('data',c=>{data+=c;if(data.length>1_000_000) reject(new Error('Слишком большой запрос'));});req.on('end',()=>{try{resolve(JSON.parse(data||'{}'));}catch{reject(new Error('Некорректный JSON'));}});req.on('error',reject);}); }
const server = http.createServer(async (req,res)=>{
  const url = new URL(req.url,'http://localhost');
  if(req.method==='OPTIONS') { res.writeHead(204, {'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET,POST,OPTIONS','Access-Control-Allow-Headers':'Content-Type'}); return res.end(); }
  if(req.method==='GET' && url.pathname==='/api/health') return send(res,200,{ok:true,configured:Boolean(API_KEY)});
  if(req.method==='POST' && url.pathname==='/api/chat') {
    if(!API_KEY) return send(res,503,{error:'На сервере ещё не настроен OPENAI_API_KEY.'});
    try {
      const body=await readBody(req); const message=String(body.message||'').slice(0,5000);
      if(!message.trim()) return send(res,400,{error:'Напиши сообщение.'});
      const study=body.study||{}; const words=Array.isArray(study.words)?study.words.slice(0,1500):[]; const stats=study.stats&&typeof study.stats==='object'?study.stats:{};
      const context = JSON.stringify({vocabulary:words.map(w=>({arabic:w.ar,translation:w.ru,plural:w.plural||'',example:w.example||'',errors:w.errors||0,correct:w.correct||0,priority:w.priority||0})),answerStats:stats}).slice(0,45000);
      const history=Array.isArray(body.history)?body.history.slice(-12).map(m=>({role:m.role==='assistant'?'assistant':'user',content:String(m.content||'').slice(0,5000)})):[];
      const instructions = `Ты — терпеливый преподаватель арабского языка, отвечающий по-русски. Добавляй харакаты к арабским словам, когда это уместно. Объясняй понятно, с примерами. Учитывай словарь и статистику ученика из контекста. Когда просят упражнения, старайся использовать только слова из его словаря; грамматические частицы и окончания можно добавлять. Не утверждай, что слово есть в словаре, если его там нет. Исправляя ответ, объясняй конкретные ошибки. Контекст словаря и статистики ученика (JSON): ${context}`;
      const response=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'Authorization':`Bearer ${API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:MODEL,instructions,input:history.length?history:[{role:'user',content:message}]})});
      const result=await response.json();
      if(!response.ok) return send(res,response.status,{error:result.error?.message||'Ошибка OpenAI API.'});
      const reply=result.output_text || (result.output||[]).flatMap(x=>x.content||[]).filter(x=>x.type==='output_text').map(x=>x.text).join('\n') || 'Не удалось получить текстовый ответ.';
      return send(res,200,{reply});
    } catch(e) { return send(res,500,{error:e.message||'Внутренняя ошибка сервера.'}); }
  }
  if(req.method!=='GET' && req.method!=='HEAD') return send(res,405,{error:'Метод не поддерживается.'});
  let file=path.join(ROOT,decodeURIComponent(url.pathname==='/'?'/index.html':url.pathname));
  if(!file.startsWith(ROOT)) return send(res,403,{error:'Forbidden'});
  fs.readFile(file,(err,content)=>{if(err){res.writeHead(404);return res.end('Not found');}res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream'});res.end(content);});
});
server.listen(PORT,()=>console.log(`Лугати запущен: http://localhost:${PORT}`));
